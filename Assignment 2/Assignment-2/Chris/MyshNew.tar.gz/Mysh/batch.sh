rm output_file.txt
rm output_file2.txt
rm search.txt
cd
cd .
pwd
cd ..
pwd
cd os_hw2
pwd
ls
ls > output_file.txt
ls
ls>output_file2.txt
ls
python p.py arg1 arg2 arg2
p.py arg1 arg2 arg2
ls &
ls
find /Users/hx2 -name *.c -print > search.txt &
ls -l
ls -l
find /Users/hx2/Desktop -name *.c -print
ls -l