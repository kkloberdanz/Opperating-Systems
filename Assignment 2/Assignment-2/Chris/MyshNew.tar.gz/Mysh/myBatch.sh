ls
cd ..
cd src
