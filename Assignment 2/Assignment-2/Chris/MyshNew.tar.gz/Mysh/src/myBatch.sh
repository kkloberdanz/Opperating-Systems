ls
pwd
cd ..
pwd
ls
