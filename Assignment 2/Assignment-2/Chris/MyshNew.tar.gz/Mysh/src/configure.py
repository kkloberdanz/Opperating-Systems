#!/usr/bin/python

import os

if not os.path.isdir("Bin"):
    os.mkdir("Bin")

if not os.path.isdir("Build"):
    os.mkdir("Build")
