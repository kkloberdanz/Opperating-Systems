#ifndef GLOBALS_H
#define GLOBALS_H

#define READ_BUFFER_SIZE 513

struct ProcessIds{
    int ids[500];
    int length;
    int place;
};

#endif /* GLOBALS_H */


