#ifndef PROBLEM2_H
#define PROBLEM2_H

#define MAX_NUM_LENGTH 10000

void __add_big_ints__(const int *, const int *, int *, int *);

void add_and_print(const char*, const char*);

#endif /* __PROBLEM2_H__ */
